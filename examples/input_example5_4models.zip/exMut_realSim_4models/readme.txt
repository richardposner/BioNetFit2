This is a test file based on example 5.
It includes two models with the same set of fixed and free parameters
The only difference between the models is slightly different reactions rules and initial conditions

Each model has its own exp file
